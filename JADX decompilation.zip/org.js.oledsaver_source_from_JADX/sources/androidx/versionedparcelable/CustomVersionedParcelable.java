package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements C0639c {
    /* renamed from: a */
    public void mo1104a(boolean z) {
    }

    /* renamed from: c */
    public void mo1106c() {
    }
}
