package android.support.p006v4.widget;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import android.support.p006v4.widget.C0341e;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.FilterQueryProvider;
import android.widget.Filterable;

/* renamed from: android.support.v4.widget.d */
public abstract class C0338d extends BaseAdapter implements C0341e.C0342a, Filterable {

    /* renamed from: a */
    protected boolean f964a;

    /* renamed from: b */
    protected boolean f965b;

    /* renamed from: c */
    protected Cursor f966c;

    /* renamed from: d */
    protected Context f967d;

    /* renamed from: e */
    protected int f968e;

    /* renamed from: f */
    protected C0339a f969f;

    /* renamed from: g */
    protected DataSetObserver f970g;

    /* renamed from: h */
    protected C0341e f971h;

    /* renamed from: i */
    protected FilterQueryProvider f972i;

    /* renamed from: android.support.v4.widget.d$a */
    private class C0339a extends ContentObserver {
        C0339a() {
            super(new Handler());
        }

        public boolean deliverSelfNotifications() {
            return true;
        }

        public void onChange(boolean z) {
            C0338d.this.mo1474b();
        }
    }

    /* renamed from: android.support.v4.widget.d$b */
    private class C0340b extends DataSetObserver {
        C0340b() {
        }

        public void onChanged() {
            C0338d.this.f964a = true;
            C0338d.this.notifyDataSetChanged();
        }

        public void onInvalidated() {
            C0338d.this.f964a = false;
            C0338d.this.notifyDataSetInvalidated();
        }
    }

    public C0338d(Context context, Cursor cursor, boolean z) {
        mo1469a(context, cursor, z ? 1 : 2);
    }

    /* renamed from: a */
    public Cursor mo1466a() {
        return this.f966c;
    }

    /* renamed from: a */
    public Cursor mo1467a(CharSequence charSequence) {
        return this.f972i != null ? this.f972i.runQuery(charSequence) : this.f966c;
    }

    /* renamed from: a */
    public abstract View mo1468a(Context context, Cursor cursor, ViewGroup viewGroup);

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo1469a(Context context, Cursor cursor, int i) {
        boolean z = true;
        if ((i & 1) == 1) {
            i |= 2;
            this.f965b = true;
        } else {
            this.f965b = false;
        }
        if (cursor == null) {
            z = false;
        }
        this.f966c = cursor;
        this.f964a = z;
        this.f967d = context;
        this.f968e = z ? cursor.getColumnIndexOrThrow("_id") : -1;
        if ((i & 2) == 2) {
            this.f969f = new C0339a();
            this.f970g = new C0340b();
        } else {
            this.f969f = null;
            this.f970g = null;
        }
        if (z) {
            if (this.f969f != null) {
                cursor.registerContentObserver(this.f969f);
            }
            if (this.f970g != null) {
                cursor.registerDataSetObserver(this.f970g);
            }
        }
    }

    /* renamed from: a */
    public void mo1470a(Cursor cursor) {
        Cursor b = mo1472b(cursor);
        if (b != null) {
            b.close();
        }
    }

    /* renamed from: a */
    public abstract void mo1471a(View view, Context context, Cursor cursor);

    /* renamed from: b */
    public Cursor mo1472b(Cursor cursor) {
        if (cursor == this.f966c) {
            return null;
        }
        Cursor cursor2 = this.f966c;
        if (cursor2 != null) {
            if (this.f969f != null) {
                cursor2.unregisterContentObserver(this.f969f);
            }
            if (this.f970g != null) {
                cursor2.unregisterDataSetObserver(this.f970g);
            }
        }
        this.f966c = cursor;
        if (cursor != null) {
            if (this.f969f != null) {
                cursor.registerContentObserver(this.f969f);
            }
            if (this.f970g != null) {
                cursor.registerDataSetObserver(this.f970g);
            }
            this.f968e = cursor.getColumnIndexOrThrow("_id");
            this.f964a = true;
            notifyDataSetChanged();
            return cursor2;
        }
        this.f968e = -1;
        this.f964a = false;
        notifyDataSetInvalidated();
        return cursor2;
    }

    /* renamed from: b */
    public View mo1473b(Context context, Cursor cursor, ViewGroup viewGroup) {
        return mo1468a(context, cursor, viewGroup);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public void mo1474b() {
        if (this.f965b && this.f966c != null && !this.f966c.isClosed()) {
            this.f964a = this.f966c.requery();
        }
    }

    /* renamed from: c */
    public CharSequence mo1475c(Cursor cursor) {
        return cursor == null ? "" : cursor.toString();
    }

    public int getCount() {
        if (!this.f964a || this.f966c == null) {
            return 0;
        }
        return this.f966c.getCount();
    }

    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (!this.f964a) {
            return null;
        }
        this.f966c.moveToPosition(i);
        if (view == null) {
            view = mo1473b(this.f967d, this.f966c, viewGroup);
        }
        mo1471a(view, this.f967d, this.f966c);
        return view;
    }

    public Filter getFilter() {
        if (this.f971h == null) {
            this.f971h = new C0341e(this);
        }
        return this.f971h;
    }

    public Object getItem(int i) {
        if (!this.f964a || this.f966c == null) {
            return null;
        }
        this.f966c.moveToPosition(i);
        return this.f966c;
    }

    public long getItemId(int i) {
        if (!this.f964a || this.f966c == null || !this.f966c.moveToPosition(i)) {
            return 0;
        }
        return this.f966c.getLong(this.f968e);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (!this.f964a) {
            throw new IllegalStateException("this should only be called when the cursor is valid");
        } else if (!this.f966c.moveToPosition(i)) {
            throw new IllegalStateException("couldn't move cursor to position " + i);
        } else {
            if (view == null) {
                view = mo1468a(this.f967d, this.f966c, viewGroup);
            }
            mo1471a(view, this.f967d, this.f966c);
            return view;
        }
    }

    public boolean hasStableIds() {
        return true;
    }
}
