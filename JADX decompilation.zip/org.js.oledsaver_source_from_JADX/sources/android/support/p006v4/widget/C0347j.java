package android.support.p006v4.widget;

import android.os.Build;
import android.support.p006v4.p015g.C0235d;
import android.support.p006v4.p015g.C0249q;
import android.util.Log;
import android.view.View;
import android.widget.PopupWindow;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* renamed from: android.support.v4.widget.j */
public final class C0347j {

    /* renamed from: a */
    private static Method f977a;

    /* renamed from: b */
    private static boolean f978b;

    /* renamed from: c */
    private static Field f979c;

    /* renamed from: d */
    private static boolean f980d;

    /* renamed from: a */
    public static void m1606a(PopupWindow popupWindow, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            popupWindow.setWindowLayoutType(i);
            return;
        }
        if (!f978b) {
            Class<PopupWindow> cls = PopupWindow.class;
            try {
                f977a = cls.getDeclaredMethod("setWindowLayoutType", new Class[]{Integer.TYPE});
                f977a.setAccessible(true);
            } catch (Exception e) {
            }
            f978b = true;
        }
        if (f977a != null) {
            try {
                f977a.invoke(popupWindow, new Object[]{Integer.valueOf(i)});
            } catch (Exception e2) {
            }
        }
    }

    /* renamed from: a */
    public static void m1607a(PopupWindow popupWindow, View view, int i, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 19) {
            popupWindow.showAsDropDown(view, i, i2, i3);
            return;
        }
        if ((C0235d.m1006a(i3, C0249q.m1059b(view)) & 7) == 5) {
            i -= popupWindow.getWidth() - view.getWidth();
        }
        popupWindow.showAsDropDown(view, i, i2);
    }

    /* renamed from: a */
    public static void m1608a(PopupWindow popupWindow, boolean z) {
        if (Build.VERSION.SDK_INT >= 23) {
            popupWindow.setOverlapAnchor(z);
        } else if (Build.VERSION.SDK_INT >= 21) {
            if (!f980d) {
                try {
                    f979c = PopupWindow.class.getDeclaredField("mOverlapAnchor");
                    f979c.setAccessible(true);
                } catch (NoSuchFieldException e) {
                    Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", e);
                }
                f980d = true;
            }
            if (f979c != null) {
                try {
                    f979c.set(popupWindow, Boolean.valueOf(z));
                } catch (IllegalAccessException e2) {
                    Log.i("PopupWindowCompatApi21", "Could not set overlap anchor field in PopupWindow", e2);
                }
            }
        }
    }
}
