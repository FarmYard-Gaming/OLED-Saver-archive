package android.support.p006v4.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.support.p006v4.p015g.C0249q;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* renamed from: android.support.v4.widget.a */
public abstract class C0333a implements View.OnTouchListener {

    /* renamed from: r */
    private static final int f931r = ViewConfiguration.getTapTimeout();

    /* renamed from: a */
    final C0334a f932a = new C0334a();

    /* renamed from: b */
    final View f933b;

    /* renamed from: c */
    boolean f934c;

    /* renamed from: d */
    boolean f935d;

    /* renamed from: e */
    boolean f936e;

    /* renamed from: f */
    private final Interpolator f937f = new AccelerateInterpolator();

    /* renamed from: g */
    private Runnable f938g;

    /* renamed from: h */
    private float[] f939h = {0.0f, 0.0f};

    /* renamed from: i */
    private float[] f940i = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: j */
    private int f941j;

    /* renamed from: k */
    private int f942k;

    /* renamed from: l */
    private float[] f943l = {0.0f, 0.0f};

    /* renamed from: m */
    private float[] f944m = {0.0f, 0.0f};

    /* renamed from: n */
    private float[] f945n = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: o */
    private boolean f946o;

    /* renamed from: p */
    private boolean f947p;

    /* renamed from: q */
    private boolean f948q;

    /* renamed from: android.support.v4.widget.a$a */
    private static class C0334a {

        /* renamed from: a */
        private int f949a;

        /* renamed from: b */
        private int f950b;

        /* renamed from: c */
        private float f951c;

        /* renamed from: d */
        private float f952d;

        /* renamed from: e */
        private long f953e = Long.MIN_VALUE;

        /* renamed from: f */
        private long f954f = 0;

        /* renamed from: g */
        private int f955g = 0;

        /* renamed from: h */
        private int f956h = 0;

        /* renamed from: i */
        private long f957i = -1;

        /* renamed from: j */
        private float f958j;

        /* renamed from: k */
        private int f959k;

        C0334a() {
        }

        /* renamed from: a */
        private float m1567a(float f) {
            return (-4.0f * f * f) + (4.0f * f);
        }

        /* renamed from: a */
        private float m1568a(long j) {
            if (j < this.f953e) {
                return 0.0f;
            }
            if (this.f957i < 0 || j < this.f957i) {
                return C0333a.m1545a(((float) (j - this.f953e)) / ((float) this.f949a), 0.0f, 1.0f) * 0.5f;
            }
            return (C0333a.m1545a(((float) (j - this.f957i)) / ((float) this.f959k), 0.0f, 1.0f) * this.f958j) + (1.0f - this.f958j);
        }

        /* renamed from: a */
        public void mo1454a() {
            this.f953e = AnimationUtils.currentAnimationTimeMillis();
            this.f957i = -1;
            this.f954f = this.f953e;
            this.f958j = 0.5f;
            this.f955g = 0;
            this.f956h = 0;
        }

        /* renamed from: a */
        public void mo1455a(float f, float f2) {
            this.f951c = f;
            this.f952d = f2;
        }

        /* renamed from: a */
        public void mo1456a(int i) {
            this.f949a = i;
        }

        /* renamed from: b */
        public void mo1457b() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f959k = C0333a.m1548a((int) (currentAnimationTimeMillis - this.f953e), 0, this.f950b);
            this.f958j = m1568a(currentAnimationTimeMillis);
            this.f957i = currentAnimationTimeMillis;
        }

        /* renamed from: b */
        public void mo1458b(int i) {
            this.f950b = i;
        }

        /* renamed from: c */
        public boolean mo1459c() {
            return this.f957i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f957i + ((long) this.f959k);
        }

        /* renamed from: d */
        public void mo1460d() {
            if (this.f954f == 0) {
                throw new RuntimeException("Cannot compute scroll delta before calling start()");
            }
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            float a = m1567a(m1568a(currentAnimationTimeMillis));
            long j = currentAnimationTimeMillis - this.f954f;
            this.f954f = currentAnimationTimeMillis;
            this.f955g = (int) (((float) j) * a * this.f951c);
            this.f956h = (int) (((float) j) * a * this.f952d);
        }

        /* renamed from: e */
        public int mo1461e() {
            return (int) (this.f951c / Math.abs(this.f951c));
        }

        /* renamed from: f */
        public int mo1462f() {
            return (int) (this.f952d / Math.abs(this.f952d));
        }

        /* renamed from: g */
        public int mo1463g() {
            return this.f955g;
        }

        /* renamed from: h */
        public int mo1464h() {
            return this.f956h;
        }
    }

    /* renamed from: android.support.v4.widget.a$b */
    private class C0335b implements Runnable {
        C0335b() {
        }

        public void run() {
            if (C0333a.this.f936e) {
                if (C0333a.this.f934c) {
                    C0333a.this.f934c = false;
                    C0333a.this.f932a.mo1454a();
                }
                C0334a aVar = C0333a.this.f932a;
                if (aVar.mo1459c() || !C0333a.this.mo1442a()) {
                    C0333a.this.f936e = false;
                    return;
                }
                if (C0333a.this.f935d) {
                    C0333a.this.f935d = false;
                    C0333a.this.mo1445b();
                }
                aVar.mo1460d();
                C0333a.this.mo1441a(aVar.mo1463g(), aVar.mo1464h());
                C0249q.m1055a(C0333a.this.f933b, (Runnable) this);
            }
        }
    }

    public C0333a(View view) {
        this.f933b = view;
        DisplayMetrics displayMetrics = Resources.getSystem().getDisplayMetrics();
        int i = (int) ((1575.0f * displayMetrics.density) + 0.5f);
        int i2 = (int) ((displayMetrics.density * 315.0f) + 0.5f);
        mo1438a((float) i, (float) i);
        mo1443b((float) i2, (float) i2);
        mo1439a(1);
        mo1450e(Float.MAX_VALUE, Float.MAX_VALUE);
        mo1448d(0.2f, 0.2f);
        mo1446c(1.0f, 1.0f);
        mo1444b(f931r);
        mo1447c(500);
        mo1449d(500);
    }

    /* renamed from: a */
    static float m1545a(float f, float f2, float f3) {
        return f > f3 ? f3 : f < f2 ? f2 : f;
    }

    /* renamed from: a */
    private float m1546a(float f, float f2, float f3, float f4) {
        float interpolation;
        float a = m1545a(f * f2, 0.0f, f3);
        float f5 = m1551f(f2 - f4, a) - m1551f(f4, a);
        if (f5 < 0.0f) {
            interpolation = -this.f937f.getInterpolation(-f5);
        } else if (f5 <= 0.0f) {
            return 0.0f;
        } else {
            interpolation = this.f937f.getInterpolation(f5);
        }
        return m1545a(interpolation, -1.0f, 1.0f);
    }

    /* renamed from: a */
    private float m1547a(int i, float f, float f2, float f3) {
        float a = m1546a(this.f939h[i], f2, this.f940i[i], f);
        if (a == 0.0f) {
            return 0.0f;
        }
        float f4 = this.f943l[i];
        float f5 = this.f944m[i];
        float f6 = this.f945n[i];
        float f7 = f4 * f3;
        return a > 0.0f ? m1545a(a * f7, f5, f6) : -m1545a((-a) * f7, f5, f6);
    }

    /* renamed from: a */
    static int m1548a(int i, int i2, int i3) {
        return i > i3 ? i3 : i < i2 ? i2 : i;
    }

    /* renamed from: c */
    private void m1549c() {
        if (this.f938g == null) {
            this.f938g = new C0335b();
        }
        this.f936e = true;
        this.f934c = true;
        if (this.f946o || this.f942k <= 0) {
            this.f938g.run();
        } else {
            C0249q.m1056a(this.f933b, this.f938g, (long) this.f942k);
        }
        this.f946o = true;
    }

    /* renamed from: d */
    private void m1550d() {
        if (this.f934c) {
            this.f936e = false;
        } else {
            this.f932a.mo1457b();
        }
    }

    /* renamed from: f */
    private float m1551f(float f, float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        switch (this.f941j) {
            case 0:
            case 1:
                if (f < f2) {
                    return f >= 0.0f ? 1.0f - (f / f2) : (!this.f936e || this.f941j != 1) ? 0.0f : 1.0f;
                }
                return 0.0f;
            case 2:
                if (f < 0.0f) {
                    return f / (-f2);
                }
                return 0.0f;
            default:
                return 0.0f;
        }
    }

    /* renamed from: a */
    public C0333a mo1438a(float f, float f2) {
        this.f945n[0] = f / 1000.0f;
        this.f945n[1] = f2 / 1000.0f;
        return this;
    }

    /* renamed from: a */
    public C0333a mo1439a(int i) {
        this.f941j = i;
        return this;
    }

    /* renamed from: a */
    public C0333a mo1440a(boolean z) {
        if (this.f947p && !z) {
            m1550d();
        }
        this.f947p = z;
        return this;
    }

    /* renamed from: a */
    public abstract void mo1441a(int i, int i2);

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo1442a() {
        C0334a aVar = this.f932a;
        int f = aVar.mo1462f();
        int e = aVar.mo1461e();
        return (f != 0 && mo1452f(f)) || (e != 0 && mo1451e(e));
    }

    /* renamed from: b */
    public C0333a mo1443b(float f, float f2) {
        this.f944m[0] = f / 1000.0f;
        this.f944m[1] = f2 / 1000.0f;
        return this;
    }

    /* renamed from: b */
    public C0333a mo1444b(int i) {
        this.f942k = i;
        return this;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: b */
    public void mo1445b() {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
        this.f933b.onTouchEvent(obtain);
        obtain.recycle();
    }

    /* renamed from: c */
    public C0333a mo1446c(float f, float f2) {
        this.f943l[0] = f / 1000.0f;
        this.f943l[1] = f2 / 1000.0f;
        return this;
    }

    /* renamed from: c */
    public C0333a mo1447c(int i) {
        this.f932a.mo1456a(i);
        return this;
    }

    /* renamed from: d */
    public C0333a mo1448d(float f, float f2) {
        this.f939h[0] = f;
        this.f939h[1] = f2;
        return this;
    }

    /* renamed from: d */
    public C0333a mo1449d(int i) {
        this.f932a.mo1458b(i);
        return this;
    }

    /* renamed from: e */
    public C0333a mo1450e(float f, float f2) {
        this.f940i[0] = f;
        this.f940i[1] = f2;
        return this;
    }

    /* renamed from: e */
    public abstract boolean mo1451e(int i);

    /* renamed from: f */
    public abstract boolean mo1452f(int i);

    public boolean onTouch(View view, MotionEvent motionEvent) {
        boolean z = true;
        if (!this.f947p) {
            return false;
        }
        switch (motionEvent.getActionMasked()) {
            case 0:
                this.f935d = true;
                this.f946o = false;
                break;
            case 1:
            case 3:
                m1550d();
                break;
            case 2:
                break;
        }
        this.f932a.mo1455a(m1547a(0, motionEvent.getX(), (float) view.getWidth(), (float) this.f933b.getWidth()), m1547a(1, motionEvent.getY(), (float) view.getHeight(), (float) this.f933b.getHeight()));
        if (!this.f936e && mo1442a()) {
            m1549c();
        }
        if (!this.f948q || !this.f936e) {
            z = false;
        }
        return z;
    }
}
