package android.support.p006v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p006v4.p015g.C0226b;
import android.support.p006v4.p015g.C0242j;
import android.support.p006v4.p015g.C0243k;
import android.support.p006v4.p015g.C0245m;
import android.support.p006v4.p015g.C0246n;
import android.support.p006v4.p015g.C0249q;
import android.support.p006v4.p015g.p016a.C0221a;
import android.support.p006v4.p015g.p016a.C0225c;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import java.util.ArrayList;

/* renamed from: android.support.v4.widget.NestedScrollView */
public class NestedScrollView extends FrameLayout implements C0242j, C0245m {

    /* renamed from: w */
    private static final C0329a f902w = new C0329a();

    /* renamed from: x */
    private static final int[] f903x = {16843130};

    /* renamed from: A */
    private float f904A;

    /* renamed from: B */
    private C0330b f905B;

    /* renamed from: a */
    private long f906a;

    /* renamed from: b */
    private final Rect f907b;

    /* renamed from: c */
    private OverScroller f908c;

    /* renamed from: d */
    private EdgeEffect f909d;

    /* renamed from: e */
    private EdgeEffect f910e;

    /* renamed from: f */
    private int f911f;

    /* renamed from: g */
    private boolean f912g;

    /* renamed from: h */
    private boolean f913h;

    /* renamed from: i */
    private View f914i;

    /* renamed from: j */
    private boolean f915j;

    /* renamed from: k */
    private VelocityTracker f916k;

    /* renamed from: l */
    private boolean f917l;

    /* renamed from: m */
    private boolean f918m;

    /* renamed from: n */
    private int f919n;

    /* renamed from: o */
    private int f920o;

    /* renamed from: p */
    private int f921p;

    /* renamed from: q */
    private int f922q;

    /* renamed from: r */
    private final int[] f923r;

    /* renamed from: s */
    private final int[] f924s;

    /* renamed from: t */
    private int f925t;

    /* renamed from: u */
    private int f926u;

    /* renamed from: v */
    private C0331c f927v;

    /* renamed from: y */
    private final C0246n f928y;

    /* renamed from: z */
    private final C0243k f929z;

    /* renamed from: android.support.v4.widget.NestedScrollView$a */
    static class C0329a extends C0226b {
        C0329a() {
        }

        /* renamed from: a */
        public void mo1011a(View view, C0221a aVar) {
            int scrollRange;
            super.mo1011a(view, aVar);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            aVar.mo975a((CharSequence) ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                aVar.mo976a(true);
                if (nestedScrollView.getScrollY() > 0) {
                    aVar.mo973a(8192);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    aVar.mo973a(4096);
                }
            }
        }

        /* renamed from: a */
        public boolean mo1013a(View view, int i, Bundle bundle) {
            if (super.mo1013a(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            switch (i) {
                case 4096:
                    int min = Math.min(((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()) + nestedScrollView.getScrollY(), nestedScrollView.getScrollRange());
                    if (min == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.mo1381c(0, min);
                    return true;
                case 8192:
                    int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (max == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.mo1381c(0, max);
                    return true;
                default:
                    return false;
            }
        }

        /* renamed from: d */
        public void mo1017d(View view, AccessibilityEvent accessibilityEvent) {
            super.mo1017d(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            C0225c.m981a(accessibilityEvent, nestedScrollView.getScrollX());
            C0225c.m982b(accessibilityEvent, nestedScrollView.getScrollRange());
        }
    }

    /* renamed from: android.support.v4.widget.NestedScrollView$b */
    public interface C0330b {
        /* renamed from: a */
        void mo1431a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    /* renamed from: android.support.v4.widget.NestedScrollView$c */
    static class C0331c extends View.BaseSavedState {
        public static final Parcelable.Creator<C0331c> CREATOR = new Parcelable.Creator<C0331c>() {
            /* renamed from: a */
            public C0331c createFromParcel(Parcel parcel) {
                return new C0331c(parcel);
            }

            /* renamed from: a */
            public C0331c[] newArray(int i) {
                return new C0331c[i];
            }
        };

        /* renamed from: a */
        public int f930a;

        C0331c(Parcel parcel) {
            super(parcel);
            this.f930a = parcel.readInt();
        }

        C0331c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.f930a + "}";
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f930a);
        }
    }

    public NestedScrollView(Context context) {
        this(context, (AttributeSet) null);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f907b = new Rect();
        this.f912g = true;
        this.f913h = false;
        this.f914i = null;
        this.f915j = false;
        this.f918m = true;
        this.f922q = -1;
        this.f923r = new int[2];
        this.f924s = new int[2];
        m1502a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f903x, i, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f928y = new C0246n(this);
        this.f929z = new C0243k(this);
        setNestedScrollingEnabled(true);
        C0249q.m1053a((View) this, (C0226b) f902w);
    }

    /* renamed from: a */
    private View m1501a(boolean z, int i, int i2) {
        boolean z2;
        ArrayList focusables = getFocusables(2);
        View view = null;
        int size = focusables.size();
        int i3 = 0;
        boolean z3 = false;
        while (i3 < size) {
            View view2 = (View) focusables.get(i3);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i < bottom && top < i2) {
                z2 = i < top && bottom < i2;
                if (view != null) {
                    boolean z4 = (z && top < view.getTop()) || (!z && bottom > view.getBottom());
                    if (z3) {
                        if (z2 && z4) {
                            z2 = z3;
                        }
                    } else if (z2) {
                        z2 = true;
                    } else if (z4) {
                        z2 = z3;
                    }
                }
                i3++;
                z3 = z2;
                view = view2;
            }
            z2 = z3;
            view2 = view;
            i3++;
            z3 = z2;
            view = view2;
        }
        return view;
    }

    /* renamed from: a */
    private void m1502a() {
        this.f908c = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f919n = viewConfiguration.getScaledTouchSlop();
        this.f920o = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f921p = viewConfiguration.getScaledMaximumFlingVelocity();
    }

    /* renamed from: a */
    private void m1503a(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f922q) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f911f = (int) motionEvent.getY(i);
            this.f922q = motionEvent.getPointerId(i);
            if (this.f916k != null) {
                this.f916k.clear();
            }
        }
    }

    /* renamed from: a */
    private boolean m1504a(int i, int i2, int i3) {
        boolean z = false;
        int height = getHeight();
        int scrollY = getScrollY();
        int i4 = scrollY + height;
        boolean z2 = i == 33;
        View a = m1501a(z2, i2, i3);
        if (a == null) {
            a = this;
        }
        if (i2 < scrollY || i3 > i4) {
            m1518g(z2 ? i2 - scrollY : i3 - i4);
            z = true;
        }
        if (a != findFocus()) {
            a.requestFocus(i);
        }
        return z;
    }

    /* renamed from: a */
    private boolean m1505a(Rect rect, boolean z) {
        int a = mo1368a(rect);
        boolean z2 = a != 0;
        if (z2) {
            if (z) {
                scrollBy(0, a);
            } else {
                mo1379b(0, a);
            }
        }
        return z2;
    }

    /* renamed from: a */
    private boolean m1506a(View view) {
        return !m1507a(view, 0, getHeight());
    }

    /* renamed from: a */
    private boolean m1507a(View view, int i, int i2) {
        view.getDrawingRect(this.f907b);
        offsetDescendantRectToMyCoords(view, this.f907b);
        return this.f907b.bottom + i >= getScrollY() && this.f907b.top - i <= getScrollY() + i2;
    }

    /* renamed from: a */
    private static boolean m1508a(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m1508a((View) parent, view2);
    }

    /* renamed from: b */
    private static int m1509b(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    /* renamed from: b */
    private void m1510b(View view) {
        view.getDrawingRect(this.f907b);
        offsetDescendantRectToMyCoords(view, this.f907b);
        int a = mo1368a(this.f907b);
        if (a != 0) {
            scrollBy(0, a);
        }
    }

    /* renamed from: b */
    private boolean m1511b() {
        if (getChildCount() <= 0) {
            return false;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return layoutParams.bottomMargin + (childAt.getHeight() + layoutParams.topMargin) > (getHeight() - getPaddingTop()) - getPaddingBottom();
    }

    /* renamed from: c */
    private void m1512c() {
        if (this.f916k == null) {
            this.f916k = VelocityTracker.obtain();
        } else {
            this.f916k.clear();
        }
    }

    /* renamed from: d */
    private void m1513d() {
        if (this.f916k == null) {
            this.f916k = VelocityTracker.obtain();
        }
    }

    /* renamed from: d */
    private boolean m1514d(int i, int i2) {
        if (getChildCount() <= 0) {
            return false;
        }
        int scrollY = getScrollY();
        View childAt = getChildAt(0);
        return i2 >= childAt.getTop() - scrollY && i2 < childAt.getBottom() - scrollY && i >= childAt.getLeft() && i < childAt.getRight();
    }

    /* renamed from: e */
    private void m1515e() {
        if (this.f916k != null) {
            this.f916k.recycle();
            this.f916k = null;
        }
    }

    /* renamed from: f */
    private void m1516f() {
        this.f915j = false;
        m1515e();
        mo1369a(0);
        if (this.f909d != null) {
            this.f909d.onRelease();
            this.f910e.onRelease();
        }
    }

    /* renamed from: g */
    private void m1517g() {
        if (getOverScrollMode() == 2) {
            this.f909d = null;
            this.f910e = null;
        } else if (this.f909d == null) {
            Context context = getContext();
            this.f909d = new EdgeEffect(context);
            this.f910e = new EdgeEffect(context);
        }
    }

    /* renamed from: g */
    private void m1518g(int i) {
        if (i == 0) {
            return;
        }
        if (this.f918m) {
            mo1379b(0, i);
        } else {
            scrollBy(0, i);
        }
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f904A == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f904A = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f904A;
    }

    /* renamed from: h */
    private void m1519h(int i) {
        int scrollY = getScrollY();
        boolean z = (scrollY > 0 || i > 0) && (scrollY < getScrollRange() || i < 0);
        if (!dispatchNestedPreFling(0.0f, (float) i)) {
            dispatchNestedFling(0.0f, (float) i, z);
            mo1398f(i);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public int mo1368a(Rect rect) {
        int i;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i2 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int i3 = rect.top > 0 ? scrollY + verticalFadingEdgeLength : scrollY;
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i4 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i2 - verticalFadingEdgeLength : i2;
        if (rect.bottom > i4 && rect.top > i3) {
            i = Math.min(rect.height() > height ? (rect.top - i3) + 0 : (rect.bottom - i4) + 0, (layoutParams.bottomMargin + childAt.getBottom()) - i2);
        } else if (rect.top >= i3 || rect.bottom >= i4) {
            i = 0;
        } else {
            i = Math.max(rect.height() > height ? 0 - (i4 - rect.bottom) : 0 - (i3 - rect.top), -getScrollY());
        }
        return i;
    }

    /* renamed from: a */
    public void mo1369a(int i) {
        this.f929z.mo1050b(i);
    }

    /* renamed from: a */
    public void mo1058a(View view, int i) {
        this.f928y.mo1064a(view, i);
        mo1369a(i);
    }

    /* renamed from: a */
    public void mo1059a(View view, int i, int i2, int i3, int i4, int i5) {
        int scrollY = getScrollY();
        scrollBy(0, i4);
        int scrollY2 = getScrollY() - scrollY;
        mo1372a(0, scrollY2, 0, i4 - scrollY2, (int[]) null, i5);
    }

    /* renamed from: a */
    public void mo1060a(View view, int i, int i2, int[] iArr, int i3) {
        mo1373a(i, i2, iArr, (int[]) null, i3);
    }

    /* renamed from: a */
    public boolean mo1370a(int i, int i2) {
        return this.f929z.mo1047a(i, i2);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public boolean mo1371a(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, boolean z) {
        boolean z2;
        boolean z3;
        int overScrollMode = getOverScrollMode();
        boolean z4 = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean z5 = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean z6 = overScrollMode == 0 || (overScrollMode == 1 && z4);
        boolean z7 = overScrollMode == 0 || (overScrollMode == 1 && z5);
        int i9 = i3 + i;
        if (!z6) {
            i7 = 0;
        }
        int i10 = i4 + i2;
        if (!z7) {
            i8 = 0;
        }
        int i11 = -i7;
        int i12 = i7 + i5;
        int i13 = -i8;
        int i14 = i8 + i6;
        if (i9 > i12) {
            z2 = true;
        } else if (i9 < i11) {
            z2 = true;
            i12 = i11;
        } else {
            z2 = false;
            i12 = i9;
        }
        if (i10 > i14) {
            z3 = true;
        } else if (i10 < i13) {
            z3 = true;
            i14 = i13;
        } else {
            z3 = false;
            i14 = i10;
        }
        if (z3 && !mo1380b(1)) {
            this.f908c.springBack(i12, i14, 0, 0, 0, getScrollRange());
        }
        onOverScrolled(i12, i14, z2, z3);
        return z2 || z3;
    }

    /* renamed from: a */
    public boolean mo1372a(int i, int i2, int i3, int i4, int[] iArr, int i5) {
        return this.f929z.mo1048a(i, i2, i3, i4, iArr, i5);
    }

    /* renamed from: a */
    public boolean mo1373a(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.f929z.mo1049a(i, i2, iArr, iArr2, i3);
    }

    /* renamed from: a */
    public boolean mo1374a(KeyEvent keyEvent) {
        int i = 33;
        this.f907b.setEmpty();
        if (!m1511b()) {
            if (!isFocused() || keyEvent.getKeyCode() == 4) {
                return false;
            }
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, 130);
            return (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(130)) ? false : true;
        } else if (keyEvent.getAction() != 0) {
            return false;
        } else {
            switch (keyEvent.getKeyCode()) {
                case 19:
                    return !keyEvent.isAltPressed() ? mo1397e(33) : mo1390d(33);
                case 20:
                    return !keyEvent.isAltPressed() ? mo1397e(130) : mo1390d(130);
                case 62:
                    if (!keyEvent.isShiftPressed()) {
                        i = 130;
                    }
                    mo1382c(i);
                    return false;
                default:
                    return false;
            }
        }
    }

    /* renamed from: a */
    public boolean mo1061a(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    public void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    public void addView(View view, int i) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, i, layoutParams);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view, layoutParams);
    }

    /* renamed from: b */
    public final void mo1379b(int i, int i2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f906a > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int height = layoutParams.bottomMargin + childAt.getHeight() + layoutParams.topMargin;
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int scrollY = getScrollY();
                this.f926u = getScrollY();
                OverScroller overScroller = this.f908c;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(scrollY + i2, Math.max(0, height - height2))) - scrollY);
                C0249q.m1047a(this);
            } else {
                if (!this.f908c.isFinished()) {
                    this.f908c.abortAnimation();
                }
                scrollBy(i, i2);
            }
            this.f906a = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    /* renamed from: b */
    public void mo1062b(View view, View view2, int i, int i2) {
        this.f928y.mo1066a(view, view2, i, i2);
        mo1370a(2, i2);
    }

    /* renamed from: b */
    public boolean mo1380b(int i) {
        return this.f929z.mo1046a(i);
    }

    /* renamed from: c */
    public final void mo1381c(int i, int i2) {
        mo1379b(i - getScrollX(), i2 - getScrollY());
    }

    /* renamed from: c */
    public boolean mo1382c(int i) {
        boolean z = i == 130;
        int height = getHeight();
        if (z) {
            this.f907b.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int bottom = ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + childAt.getBottom() + getPaddingBottom();
                if (this.f907b.top + height > bottom) {
                    this.f907b.top = bottom - height;
                }
            }
        } else {
            this.f907b.top = getScrollY() - height;
            if (this.f907b.top < 0) {
                this.f907b.top = 0;
            }
        }
        this.f907b.bottom = this.f907b.top + height;
        return m1504a(i, this.f907b.top, this.f907b.bottom);
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        if (this.f908c.computeScrollOffset()) {
            this.f908c.getCurrX();
            int currY = this.f908c.getCurrY();
            int i = currY - this.f926u;
            if (mo1373a(0, i, this.f924s, (int[]) null, 1)) {
                i -= this.f924s[1];
            }
            if (i != 0) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                mo1371a(0, i, getScrollX(), scrollY, 0, scrollRange, 0, 0, false);
                int scrollY2 = getScrollY() - scrollY;
                if (!mo1372a(0, scrollY2, 0, i - scrollY2, (int[]) null, 1)) {
                    int overScrollMode = getOverScrollMode();
                    if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                        m1517g();
                        if (currY <= 0 && scrollY > 0) {
                            this.f909d.onAbsorb((int) this.f908c.getCurrVelocity());
                        } else if (currY >= scrollRange && scrollY < scrollRange) {
                            this.f910e.onAbsorb((int) this.f908c.getCurrVelocity());
                        }
                    }
                }
            }
            this.f926u = currY;
            C0249q.m1047a(this);
            return;
        }
        if (mo1380b(1)) {
            mo1369a(1);
        }
        this.f926u = 0;
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + childAt.getBottom();
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    /* renamed from: d */
    public boolean mo1390d(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        this.f907b.top = 0;
        this.f907b.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f907b.bottom = ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + childAt.getBottom() + getPaddingBottom();
            this.f907b.top = this.f907b.bottom - height;
        }
        return m1504a(i, this.f907b.top, this.f907b.bottom);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo1374a(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f929z.mo1045a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f929z.mo1044a(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return mo1373a(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return mo1372a(i, i2, i3, i4, iArr, 0);
    }

    public void draw(Canvas canvas) {
        int i;
        int i2 = 0;
        super.draw(canvas);
        if (this.f909d != null) {
            int scrollY = getScrollY();
            if (!this.f909d.isFinished()) {
                int save = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int min = Math.min(0, scrollY);
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width -= getPaddingLeft() + getPaddingRight();
                    i = getPaddingLeft() + 0;
                } else {
                    i = 0;
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height -= getPaddingTop() + getPaddingBottom();
                    min += getPaddingTop();
                }
                canvas.translate((float) i, (float) min);
                this.f909d.setSize(width, height);
                if (this.f909d.draw(canvas)) {
                    C0249q.m1047a(this);
                }
                canvas.restoreToCount(save);
            }
            if (!this.f910e.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int max = Math.max(getScrollRange(), scrollY) + height2;
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width2 -= getPaddingLeft() + getPaddingRight();
                    i2 = 0 + getPaddingLeft();
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height2 -= getPaddingTop() + getPaddingBottom();
                    max -= getPaddingBottom();
                }
                canvas.translate((float) (i2 - width2), (float) max);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f910e.setSize(width2, height2);
                if (this.f910e.draw(canvas)) {
                    C0249q.m1047a(this);
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    /* renamed from: e */
    public boolean mo1397e(int i) {
        int i2;
        View findFocus = findFocus();
        View view = findFocus == this ? null : findFocus;
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !m1507a(findNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                i2 = getScrollY();
            } else if (i != 130 || getChildCount() <= 0) {
                i2 = maxScrollAmount;
            } else {
                View childAt = getChildAt(0);
                i2 = Math.min((((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + childAt.getBottom()) - ((getScrollY() + getHeight()) - getPaddingBottom()), maxScrollAmount);
            }
            if (i2 == 0) {
                return false;
            }
            if (i != 130) {
                i2 = -i2;
            }
            m1518g(i2);
        } else {
            findNextFocus.getDrawingRect(this.f907b);
            offsetDescendantRectToMyCoords(findNextFocus, this.f907b);
            m1518g(mo1368a(this.f907b));
            findNextFocus.requestFocus(i);
        }
        if (view != null && view.isFocused() && m1506a(view)) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    /* renamed from: f */
    public void mo1398f(int i) {
        if (getChildCount() > 0) {
            mo1370a(2, 1);
            this.f908c.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.f926u = getScrollY();
            C0249q.m1047a(this);
        }
    }

    /* access modifiers changed from: protected */
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + childAt.getBottom()) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (0.5f * ((float) getHeight()));
    }

    public int getNestedScrollAxes() {
        return this.f928y.mo1063a();
    }

    /* access modifiers changed from: package-private */
    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, (layoutParams.bottomMargin + (childAt.getHeight() + layoutParams.topMargin)) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    /* access modifiers changed from: protected */
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public boolean hasNestedScrollingParent() {
        return mo1380b(0);
    }

    public boolean isNestedScrollingEnabled() {
        return this.f929z.mo1043a();
    }

    /* access modifiers changed from: protected */
    public void measureChild(View view, int i, int i2) {
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    /* access modifiers changed from: protected */
    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.bottomMargin + marginLayoutParams.topMargin, 0));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f913h = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) == 0) {
            return false;
        }
        switch (motionEvent.getAction()) {
            case 8:
                if (this.f915j) {
                    return false;
                }
                float axisValue = motionEvent.getAxisValue(9);
                if (axisValue == 0.0f) {
                    return false;
                }
                int verticalScrollFactorCompat = (int) (axisValue * getVerticalScrollFactorCompat());
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int i = scrollY - verticalScrollFactorCompat;
                if (i < 0) {
                    scrollRange = 0;
                } else if (i <= scrollRange) {
                    scrollRange = i;
                }
                if (scrollRange == scrollY) {
                    return false;
                }
                super.scrollTo(getScrollX(), scrollRange);
                return true;
            default:
                return false;
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z = true;
        int action = motionEvent.getAction();
        if (action == 2 && this.f915j) {
            return true;
        }
        switch (action & 255) {
            case 0:
                int y = (int) motionEvent.getY();
                if (m1514d((int) motionEvent.getX(), y)) {
                    this.f911f = y;
                    this.f922q = motionEvent.getPointerId(0);
                    m1512c();
                    this.f916k.addMovement(motionEvent);
                    this.f908c.computeScrollOffset();
                    if (this.f908c.isFinished()) {
                        z = false;
                    }
                    this.f915j = z;
                    mo1370a(2, 0);
                    break;
                } else {
                    this.f915j = false;
                    m1515e();
                    break;
                }
            case 1:
            case 3:
                this.f915j = false;
                this.f922q = -1;
                m1515e();
                if (this.f908c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    C0249q.m1047a(this);
                }
                mo1369a(0);
                break;
            case 2:
                int i = this.f922q;
                if (i != -1) {
                    int findPointerIndex = motionEvent.findPointerIndex(i);
                    if (findPointerIndex != -1) {
                        int y2 = (int) motionEvent.getY(findPointerIndex);
                        if (Math.abs(y2 - this.f911f) > this.f919n && (getNestedScrollAxes() & 2) == 0) {
                            this.f915j = true;
                            this.f911f = y2;
                            m1513d();
                            this.f916k.addMovement(motionEvent);
                            this.f925t = 0;
                            ViewParent parent = getParent();
                            if (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                                break;
                            }
                        }
                    } else {
                        Log.e("NestedScrollView", "Invalid pointerId=" + i + " in onInterceptTouchEvent");
                        break;
                    }
                }
                break;
            case 6:
                m1503a(motionEvent);
                break;
        }
        return this.f915j;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = 0;
        super.onLayout(z, i, i2, i3, i4);
        this.f912g = false;
        if (this.f914i != null && m1508a(this.f914i, (View) this)) {
            m1510b(this.f914i);
        }
        this.f914i = null;
        if (!this.f913h) {
            if (this.f927v != null) {
                scrollTo(getScrollX(), this.f927v.f930a);
                this.f927v = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i5 = layoutParams.bottomMargin + childAt.getMeasuredHeight() + layoutParams.topMargin;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int b = m1509b(scrollY, paddingTop, i5);
            if (b != scrollY) {
                scrollTo(getScrollX(), b);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f913h = true;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f917l && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        m1519h((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo1060a(view, i, i2, iArr, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo1059a(view, i, i2, i3, i4, 0);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        mo1062b(view, view2, i, 0);
    }

    /* access modifiers changed from: protected */
    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View findNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, (View) null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (findNextFocus != null && !m1506a(findNextFocus)) {
            return findNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0331c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0331c cVar = (C0331c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.f927v = cVar;
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        C0331c cVar = new C0331c(super.onSaveInstanceState());
        cVar.f930a = getScrollY();
        return cVar;
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        if (this.f905B != null) {
            this.f905B.mo1431a(this, i, i2, i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && m1507a(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f907b);
            offsetDescendantRectToMyCoords(findFocus, this.f907b);
            m1518g(mo1368a(this.f907b));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return mo1061a(view, view2, i, 0);
    }

    public void onStopNestedScroll(View view) {
        mo1058a(view, 0);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        m1513d();
        MotionEvent obtain = MotionEvent.obtain(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f925t = 0;
        }
        obtain.offsetLocation(0.0f, (float) this.f925t);
        switch (actionMasked) {
            case 0:
                if (getChildCount() != 0) {
                    boolean z = !this.f908c.isFinished();
                    this.f915j = z;
                    if (z && (parent = getParent()) != null) {
                        parent.requestDisallowInterceptTouchEvent(true);
                    }
                    if (!this.f908c.isFinished()) {
                        this.f908c.abortAnimation();
                    }
                    this.f911f = (int) motionEvent.getY();
                    this.f922q = motionEvent.getPointerId(0);
                    mo1370a(2, 0);
                    break;
                } else {
                    return false;
                }
            case 1:
                VelocityTracker velocityTracker = this.f916k;
                velocityTracker.computeCurrentVelocity(1000, (float) this.f921p);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f922q);
                if (Math.abs(yVelocity) > this.f920o) {
                    m1519h(-yVelocity);
                } else if (this.f908c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    C0249q.m1047a(this);
                }
                this.f922q = -1;
                m1516f();
                break;
            case 2:
                int findPointerIndex = motionEvent.findPointerIndex(this.f922q);
                if (findPointerIndex != -1) {
                    int y = (int) motionEvent.getY(findPointerIndex);
                    int i = this.f911f - y;
                    if (mo1373a(0, i, this.f924s, this.f923r, 0)) {
                        i -= this.f924s[1];
                        obtain.offsetLocation(0.0f, (float) this.f923r[1]);
                        this.f925t += this.f923r[1];
                    }
                    if (!this.f915j && Math.abs(i) > this.f919n) {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f915j = true;
                        i = i > 0 ? i - this.f919n : i + this.f919n;
                    }
                    if (this.f915j) {
                        this.f911f = y - this.f923r[1];
                        int scrollY = getScrollY();
                        int scrollRange = getScrollRange();
                        int overScrollMode = getOverScrollMode();
                        boolean z2 = overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0);
                        if (mo1371a(0, i, 0, getScrollY(), 0, scrollRange, 0, 0, true) && !mo1380b(0)) {
                            this.f916k.clear();
                        }
                        int scrollY2 = getScrollY() - scrollY;
                        if (!mo1372a(0, scrollY2, 0, i - scrollY2, this.f923r, 0)) {
                            if (z2) {
                                m1517g();
                                int i2 = scrollY + i;
                                if (i2 < 0) {
                                    C0343f.m1597a(this.f909d, ((float) i) / ((float) getHeight()), motionEvent.getX(findPointerIndex) / ((float) getWidth()));
                                    if (!this.f910e.isFinished()) {
                                        this.f910e.onRelease();
                                    }
                                } else if (i2 > scrollRange) {
                                    C0343f.m1597a(this.f910e, ((float) i) / ((float) getHeight()), 1.0f - (motionEvent.getX(findPointerIndex) / ((float) getWidth())));
                                    if (!this.f909d.isFinished()) {
                                        this.f909d.onRelease();
                                    }
                                }
                                if (this.f909d != null && (!this.f909d.isFinished() || !this.f910e.isFinished())) {
                                    C0249q.m1047a(this);
                                    break;
                                }
                            }
                        } else {
                            this.f911f -= this.f923r[1];
                            obtain.offsetLocation(0.0f, (float) this.f923r[1]);
                            this.f925t += this.f923r[1];
                            break;
                        }
                    }
                } else {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f922q + " in onTouchEvent");
                    break;
                }
                break;
            case 3:
                if (this.f915j && getChildCount() > 0 && this.f908c.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    C0249q.m1047a(this);
                }
                this.f922q = -1;
                m1516f();
                break;
            case 5:
                int actionIndex = motionEvent.getActionIndex();
                this.f911f = (int) motionEvent.getY(actionIndex);
                this.f922q = motionEvent.getPointerId(actionIndex);
                break;
            case 6:
                m1503a(motionEvent);
                this.f911f = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f922q));
                break;
        }
        if (this.f916k != null) {
            this.f916k.addMovement(obtain);
        }
        obtain.recycle();
        return true;
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f912g) {
            m1510b(view2);
        } else {
            this.f914i = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        return m1505a(rect, z);
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            m1515e();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        this.f912g = true;
        super.requestLayout();
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = layoutParams.bottomMargin + childAt.getHeight() + layoutParams.topMargin;
            int b = m1509b(i, width, width2);
            int b2 = m1509b(i2, height, height2);
            if (b != getScrollX() || b2 != getScrollY()) {
                super.scrollTo(b, b2);
            }
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.f917l) {
            this.f917l = z;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.f929z.mo1042a(z);
    }

    public void setOnScrollChangeListener(C0330b bVar) {
        this.f905B = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.f918m = z;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i) {
        return mo1370a(i, 0);
    }

    public void stopNestedScroll() {
        mo1369a(0);
    }
}
