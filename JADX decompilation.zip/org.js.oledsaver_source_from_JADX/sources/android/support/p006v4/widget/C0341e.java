package android.support.p006v4.widget;

import android.database.Cursor;
import android.widget.Filter;

/* renamed from: android.support.v4.widget.e */
class C0341e extends Filter {

    /* renamed from: a */
    C0342a f975a;

    /* renamed from: android.support.v4.widget.e$a */
    interface C0342a {
        /* renamed from: a */
        Cursor mo1466a();

        /* renamed from: a */
        Cursor mo1467a(CharSequence charSequence);

        /* renamed from: a */
        void mo1470a(Cursor cursor);

        /* renamed from: c */
        CharSequence mo1475c(Cursor cursor);
    }

    C0341e(C0342a aVar) {
        this.f975a = aVar;
    }

    public CharSequence convertResultToString(Object obj) {
        return this.f975a.mo1475c((Cursor) obj);
    }

    /* access modifiers changed from: protected */
    public Filter.FilterResults performFiltering(CharSequence charSequence) {
        Cursor a = this.f975a.mo1467a(charSequence);
        Filter.FilterResults filterResults = new Filter.FilterResults();
        if (a != null) {
            filterResults.count = a.getCount();
            filterResults.values = a;
        } else {
            filterResults.count = 0;
            filterResults.values = null;
        }
        return filterResults;
    }

    /* access modifiers changed from: protected */
    public void publishResults(CharSequence charSequence, Filter.FilterResults filterResults) {
        Cursor a = this.f975a.mo1466a();
        if (filterResults.values != null && filterResults.values != a) {
            this.f975a.mo1470a((Cursor) filterResults.values);
        }
    }
}
