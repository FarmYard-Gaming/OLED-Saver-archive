package android.support.p006v4.widget;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: android.support.v4.widget.k */
public abstract class C0348k extends C0338d {

    /* renamed from: j */
    private int f981j;

    /* renamed from: k */
    private int f982k;

    /* renamed from: l */
    private LayoutInflater f983l;

    @Deprecated
    public C0348k(Context context, int i, Cursor cursor, boolean z) {
        super(context, cursor, z);
        this.f982k = i;
        this.f981j = i;
        this.f983l = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    /* renamed from: a */
    public View mo1468a(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.f983l.inflate(this.f981j, viewGroup, false);
    }

    /* renamed from: b */
    public View mo1473b(Context context, Cursor cursor, ViewGroup viewGroup) {
        return this.f983l.inflate(this.f982k, viewGroup, false);
    }
}
