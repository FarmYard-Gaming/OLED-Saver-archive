package android.support.p006v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.widget.CompoundButton;
import java.lang.reflect.Field;

/* renamed from: android.support.v4.widget.c */
public final class C0337c {

    /* renamed from: a */
    private static Field f962a;

    /* renamed from: b */
    private static boolean f963b;

    /* renamed from: a */
    public static Drawable m1580a(CompoundButton compoundButton) {
        if (Build.VERSION.SDK_INT >= 23) {
            return compoundButton.getButtonDrawable();
        }
        if (!f963b) {
            try {
                f962a = CompoundButton.class.getDeclaredField("mButtonDrawable");
                f962a.setAccessible(true);
            } catch (NoSuchFieldException e) {
                Log.i("CompoundButtonCompat", "Failed to retrieve mButtonDrawable field", e);
            }
            f963b = true;
        }
        if (f962a != null) {
            try {
                return (Drawable) f962a.get(compoundButton);
            } catch (IllegalAccessException e2) {
                Log.i("CompoundButtonCompat", "Failed to get button drawable via reflection", e2);
                f962a = null;
            }
        }
        return null;
    }

    /* renamed from: a */
    public static void m1581a(CompoundButton compoundButton, ColorStateList colorStateList) {
        if (Build.VERSION.SDK_INT >= 21) {
            compoundButton.setButtonTintList(colorStateList);
        } else if (compoundButton instanceof C0351m) {
            ((C0351m) compoundButton).setSupportButtonTintList(colorStateList);
        }
    }

    /* renamed from: a */
    public static void m1582a(CompoundButton compoundButton, PorterDuff.Mode mode) {
        if (Build.VERSION.SDK_INT >= 21) {
            compoundButton.setButtonTintMode(mode);
        } else if (compoundButton instanceof C0351m) {
            ((C0351m) compoundButton).setSupportButtonTintMode(mode);
        }
    }
}
