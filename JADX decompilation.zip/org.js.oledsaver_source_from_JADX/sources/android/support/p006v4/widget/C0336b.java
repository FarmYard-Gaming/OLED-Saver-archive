package android.support.p006v4.widget;

import android.os.Build;

/* renamed from: android.support.v4.widget.b */
public interface C0336b {

    /* renamed from: a */
    public static final boolean f961a = (Build.VERSION.SDK_INT >= 27);
}
