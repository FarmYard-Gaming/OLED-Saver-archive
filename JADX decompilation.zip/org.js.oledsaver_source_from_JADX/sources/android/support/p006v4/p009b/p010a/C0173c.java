package android.support.p006v4.p009b.p010a;

import android.view.SubMenu;

/* renamed from: android.support.v4.b.a.c */
public interface C0173c extends C0171a, SubMenu {
}
