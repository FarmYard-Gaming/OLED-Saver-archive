package android.support.p006v4.p009b.p010a;

import android.view.Menu;

/* renamed from: android.support.v4.b.a.a */
public interface C0171a extends Menu {
}
