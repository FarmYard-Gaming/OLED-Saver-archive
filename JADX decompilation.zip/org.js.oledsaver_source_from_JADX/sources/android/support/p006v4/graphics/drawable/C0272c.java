package android.support.p006v4.graphics.drawable;

import android.graphics.drawable.Drawable;

/* renamed from: android.support.v4.graphics.drawable.c */
public interface C0272c {
    /* renamed from: a */
    Drawable mo1108a();

    /* renamed from: a */
    void mo1109a(Drawable drawable);
}
