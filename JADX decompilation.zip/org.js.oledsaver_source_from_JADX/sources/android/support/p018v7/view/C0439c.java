package android.support.p018v7.view;

/* renamed from: android.support.v7.view.c */
public interface C0439c {
    /* renamed from: a */
    void mo1875a();

    /* renamed from: b */
    void mo1876b();
}
