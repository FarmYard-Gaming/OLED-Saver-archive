package android.support.p018v7.view.menu;

import android.widget.ListView;

/* renamed from: android.support.v7.view.menu.s */
public interface C0487s {
    /* renamed from: a */
    void mo2033a();

    /* renamed from: c */
    void mo2040c();

    /* renamed from: d */
    boolean mo2043d();

    /* renamed from: e */
    ListView mo2044e();
}
