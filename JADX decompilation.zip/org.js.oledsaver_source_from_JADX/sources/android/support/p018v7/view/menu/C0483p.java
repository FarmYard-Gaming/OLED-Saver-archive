package android.support.p018v7.view.menu;

/* renamed from: android.support.v7.view.menu.p */
public interface C0483p {

    /* renamed from: android.support.v7.view.menu.p$a */
    public interface C0484a {
        /* renamed from: a */
        void mo1936a(C0469j jVar, int i);

        /* renamed from: a */
        boolean mo1937a();

        C0469j getItemData();
    }

    /* renamed from: a */
    void mo1958a(C0465h hVar);
}
