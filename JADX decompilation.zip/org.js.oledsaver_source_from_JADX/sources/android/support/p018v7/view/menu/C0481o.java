package android.support.p018v7.view.menu;

import android.content.Context;

/* renamed from: android.support.v7.view.menu.o */
public interface C0481o {

    /* renamed from: android.support.v7.view.menu.o$a */
    public interface C0482a {
        /* renamed from: a */
        void mo1665a(C0465h hVar, boolean z);

        /* renamed from: a */
        boolean mo1666a(C0465h hVar);
    }

    /* renamed from: a */
    void mo2015a(Context context, C0465h hVar);

    /* renamed from: a */
    void mo2016a(C0465h hVar, boolean z);

    /* renamed from: a */
    void mo2018a(C0482a aVar);

    /* renamed from: a */
    boolean mo2021a(C0465h hVar, C0469j jVar);

    /* renamed from: a */
    boolean mo2022a(C0491u uVar);

    /* renamed from: b */
    void mo2025b(boolean z);

    /* renamed from: b */
    boolean mo2026b();

    /* renamed from: b */
    boolean mo2027b(C0465h hVar, C0469j jVar);
}
