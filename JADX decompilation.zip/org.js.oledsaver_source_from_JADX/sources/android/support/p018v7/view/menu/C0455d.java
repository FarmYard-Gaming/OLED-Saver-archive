package android.support.p018v7.view.menu;

/* renamed from: android.support.v7.view.menu.d */
class C0455d<T> {

    /* renamed from: b */
    final T f1499b;

    C0455d(T t) {
        if (t == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.f1499b = t;
    }
}
