package android.support.p018v7.app;

import android.support.p018v7.view.C0437b;

/* renamed from: android.support.v7.app.d */
public interface C0385d {
    /* renamed from: a */
    C0437b mo1580a(C0437b.C0438a aVar);

    /* renamed from: a */
    void mo1582a(C0437b bVar);

    /* renamed from: b */
    void mo1587b(C0437b bVar);
}
