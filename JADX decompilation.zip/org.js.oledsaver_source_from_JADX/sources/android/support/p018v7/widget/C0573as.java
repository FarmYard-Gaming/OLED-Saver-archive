package android.support.p018v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* renamed from: android.support.v7.widget.as */
class C0573as {

    /* renamed from: a */
    public ColorStateList f2086a;

    /* renamed from: b */
    public PorterDuff.Mode f2087b;

    /* renamed from: c */
    public boolean f2088c;

    /* renamed from: d */
    public boolean f2089d;

    C0573as() {
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public void mo2954a() {
        this.f2086a = null;
        this.f2089d = false;
        this.f2087b = null;
        this.f2088c = false;
    }
}
