package android.support.p018v7.widget;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

/* renamed from: android.support.v7.widget.aq */
public interface C0571aq extends SpinnerAdapter {
    /* renamed from: a */
    Resources.Theme mo2948a();

    /* renamed from: a */
    void mo2949a(Resources.Theme theme);
}
