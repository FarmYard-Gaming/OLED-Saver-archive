package android.support.p018v7.widget;

import android.graphics.Rect;

/* renamed from: android.support.v7.widget.af */
public interface C0543af {

    /* renamed from: android.support.v7.widget.af$a */
    public interface C0544a {
        /* renamed from: a */
        void mo1661a(Rect rect);
    }

    void setOnFitSystemWindowsListener(C0544a aVar);
}
