package android.support.p018v7.widget;

/* renamed from: android.support.v7.widget.bb */
public interface C0587bb {
    /* renamed from: a */
    CharSequence mo3000a();
}
