package android.support.p018v7.widget;

import android.support.p018v7.view.menu.C0481o;
import android.view.Menu;
import android.view.Window;

/* renamed from: android.support.v7.widget.ab */
public interface C0537ab {
    /* renamed from: a */
    void mo2383a(int i);

    /* renamed from: a */
    void mo2384a(Menu menu, C0481o.C0482a aVar);

    /* renamed from: e */
    boolean mo2391e();

    /* renamed from: f */
    boolean mo2392f();

    /* renamed from: g */
    boolean mo2394g();

    /* renamed from: h */
    boolean mo2401h();

    /* renamed from: i */
    boolean mo2402i();

    /* renamed from: j */
    void mo2403j();

    /* renamed from: k */
    void mo2404k();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
