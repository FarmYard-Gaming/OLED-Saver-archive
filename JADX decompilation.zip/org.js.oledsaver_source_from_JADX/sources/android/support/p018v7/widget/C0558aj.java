package android.support.p018v7.widget;

import android.support.p018v7.view.menu.C0465h;
import android.view.MenuItem;

/* renamed from: android.support.v7.widget.aj */
public interface C0558aj {
    /* renamed from: a */
    void mo2051a(C0465h hVar, MenuItem menuItem);

    /* renamed from: b */
    void mo2052b(C0465h hVar, MenuItem menuItem);
}
