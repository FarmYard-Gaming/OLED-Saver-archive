package android.support.p018v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p006v4.p015g.C0256u;
import android.support.p018v7.view.menu.C0465h;
import android.support.p018v7.view.menu.C0481o;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;

/* renamed from: android.support.v7.widget.ac */
public interface C0538ac {
    /* renamed from: a */
    C0256u mo2731a(int i, long j);

    /* renamed from: a */
    ViewGroup mo2732a();

    /* renamed from: a */
    void mo2733a(int i);

    /* renamed from: a */
    void mo2734a(Drawable drawable);

    /* renamed from: a */
    void mo2735a(C0481o.C0482a aVar, C0465h.C0466a aVar2);

    /* renamed from: a */
    void mo2736a(C0563an anVar);

    /* renamed from: a */
    void mo2737a(Menu menu, C0481o.C0482a aVar);

    /* renamed from: a */
    void mo2738a(Window.Callback callback);

    /* renamed from: a */
    void mo2739a(CharSequence charSequence);

    /* renamed from: a */
    void mo2740a(boolean z);

    /* renamed from: b */
    Context mo2741b();

    /* renamed from: b */
    void mo2742b(int i);

    /* renamed from: b */
    void mo2743b(boolean z);

    /* renamed from: c */
    void mo2744c(int i);

    /* renamed from: c */
    boolean mo2745c();

    /* renamed from: d */
    void mo2746d();

    /* renamed from: d */
    void mo2747d(int i);

    /* renamed from: e */
    CharSequence mo2748e();

    /* renamed from: f */
    void mo2749f();

    /* renamed from: g */
    void mo2750g();

    /* renamed from: h */
    boolean mo2751h();

    /* renamed from: i */
    boolean mo2752i();

    /* renamed from: j */
    boolean mo2753j();

    /* renamed from: k */
    boolean mo2754k();

    /* renamed from: l */
    boolean mo2755l();

    /* renamed from: m */
    void mo2756m();

    /* renamed from: n */
    void mo2757n();

    /* renamed from: o */
    int mo2758o();

    /* renamed from: p */
    int mo2759p();

    /* renamed from: q */
    Menu mo2760q();
}
