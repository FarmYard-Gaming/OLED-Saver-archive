package android.support.p003a;

import org.p024js.oledsaver.R;

/* renamed from: android.support.a.a */
public final class C0042a {

    /* renamed from: android.support.a.a$a */
    public static final class C0043a {
        public static final int alpha = 2130968615;
        public static final int font = 2130968707;
        public static final int fontProviderAuthority = 2130968709;
        public static final int fontProviderCerts = 2130968710;
        public static final int fontProviderFetchStrategy = 2130968711;
        public static final int fontProviderFetchTimeout = 2130968712;
        public static final int fontProviderPackage = 2130968713;
        public static final int fontProviderQuery = 2130968714;
        public static final int fontStyle = 2130968715;
        public static final int fontVariationSettings = 2130968716;
        public static final int fontWeight = 2130968717;
        public static final int ttcIndex = 2130968903;
    }

    /* renamed from: android.support.a.a$b */
    public static final class C0044b {
        public static final int action_container = 2131361806;
        public static final int action_divider = 2131361808;
        public static final int action_image = 2131361809;
        public static final int action_text = 2131361816;
        public static final int actions = 2131361817;
        public static final int async = 2131361826;
        public static final int blocking = 2131361829;
        public static final int chronometer = 2131361878;
        public static final int forever = 2131361904;
        public static final int icon = 2131361912;
        public static final int icon_group = 2131361913;
        public static final int info = 2131361918;
        public static final int italic = 2131361920;
        public static final int line1 = 2131361922;
        public static final int line3 = 2131361923;
        public static final int normal = 2131361936;
        public static final int notification_background = 2131361938;
        public static final int notification_main_column = 2131361940;
        public static final int notification_main_column_container = 2131361941;
        public static final int right_icon = 2131361960;
        public static final int right_side = 2131361961;
        public static final int tag_transition_group = 2131362001;
        public static final int tag_unhandled_key_event_manager = 2131362002;
        public static final int tag_unhandled_key_listeners = 2131362003;
        public static final int text = 2131362005;
        public static final int text2 = 2131362006;
        public static final int time = 2131362012;
        public static final int title = 2131362013;
    }

    /* renamed from: android.support.a.a$c */
    public static final class C0045c {
        public static final int[] ColorStateListItem = {16843173, 16843551, R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
    }
}
